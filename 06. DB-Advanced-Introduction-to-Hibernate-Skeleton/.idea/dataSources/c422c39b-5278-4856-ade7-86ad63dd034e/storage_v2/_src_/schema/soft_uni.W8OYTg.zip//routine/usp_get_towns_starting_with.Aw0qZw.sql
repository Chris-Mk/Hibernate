create
    definer = root@localhost procedure usp_get_towns_starting_with(IN input_str varchar(50))
BEGIN
	DECLARE town_wild_card VARCHAR(50);
    SET town_wild_card := concat(input_str, '%');
    
    SELECT t.name
    FROM towns t
    WHERE lower(t.name) LIKE lower(town_wild_card)
    ORDER BY t.name;
END;

