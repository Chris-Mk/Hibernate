create
    definer = root@localhost function ufn_get_salary_level(employee_salary decimal(19, 4)) returns varchar(7)
BEGIN
	DECLARE salary_level VARCHAR(7);
	SET salary_level := 
    (CASE
		WHEN employee_salary < 30000 THEN 'Low'
		WHEN employee_salary BETWEEN 30000 AND 50000 THEN 'Average'
		ELSE 'High'
	END);
    RETURN salary_level;
END;

