create
    definer = root@localhost function ufn_calculate_future_value(initial_sum double, yearly_interest_rate decimal(5, 2),
                                                                 number_of_years int) returns double
BEGIN 
	DECLARE future_sum DOUBLE;
    SET future_sum := initial_sum * (POW((1 + yearly_interest_rate), number_of_years));
    RETURN future_sum;
END;

