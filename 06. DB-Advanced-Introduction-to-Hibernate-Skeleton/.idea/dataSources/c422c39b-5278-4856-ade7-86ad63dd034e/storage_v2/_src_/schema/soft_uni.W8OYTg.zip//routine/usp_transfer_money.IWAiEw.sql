create
    definer = root@localhost procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount double)
BEGIN
	START TRANSACTION;
    IF (from_account_id < 1
		OR to_account_id < 1
		OR from_account_id > (SELECT COUNT(id) FROM accounts)
        OR to_account_id > (SELECT COUNT(id) FROM accounts)
        OR amount < 0
        OR (SELECT balance FROM accounts WHERE id = from_account_id) < amount
        OR from_account_id = to_account_id) THEN
        ROLLBACK;
	ELSE
		UPDATE accounts
        SET balance = balance - amount
        WHERE id = from_account_id;
        
        UPDATE accounts
        SET balance = balance + amount
        WHERE id = to_account_id;
        
        COMMIT;
    END IF;
END;

