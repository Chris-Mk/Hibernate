create
    definer = root@localhost function ufn_count_employees_by_town(town_name varchar(50)) returns int
BEGIN
	DECLARE employees_town_count INT;
    SET employees_town_count := 
		(SELECT count(e.employee_id)
        FROM employees e
        JOIN addresses a
			USING (address_id)
		JOIN towns t
			USING (town_id)
		WHERE t.name = town_name);
	RETURN employees_town_count;
END;

