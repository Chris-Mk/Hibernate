create view v_employees_job_titles as
select concat_ws(' ', `soft_uni`.`employees`.`first_name`,
                 if((`soft_uni`.`employees`.`middle_name` is null), '', `soft_uni`.`employees`.`middle_name`),
                 `soft_uni`.`employees`.`last_name`) AS `full_name`,
       `soft_uni`.`employees`.`job_title`            AS `job_title`
from `soft_uni`.`employees`;

