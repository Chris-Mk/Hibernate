create
    definer = root@localhost procedure usp_withdraw_money(IN account_id int, IN money_amount double)
BEGIN
	START TRANSACTION;
    IF (money_amount < 0 OR (SELECT balance FROM accounts WHERE id = account_id) < money_amount) THEN
		ROLLBACK;
	ELSE
		UPDATE accounts
        SET balance = balance - money_amount
        WHERE id = account_id;
    END IF;
END;

