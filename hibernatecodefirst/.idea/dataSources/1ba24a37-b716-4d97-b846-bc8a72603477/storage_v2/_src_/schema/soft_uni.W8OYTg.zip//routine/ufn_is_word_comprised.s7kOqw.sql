create
    definer = root@localhost function ufn_is_word_comprised(set_of_letters varchar(50), word varchar(50)) returns bit
BEGIN
	DECLARE is_comprised BIT;
	DECLARE current_index INT;
    DECLARE word_length INT;
    
    SET is_comprised := 1;
    SET current_index := 1;
    SET word_length := char_length(word);
    
    WHILE (current_index <= word_length) DO
		IF (set_of_letters NOT LIKE concat('%', substring(word, current_index, 1), '%')) THEN
			SET is_comprised := 0;
		END IF;
        
        SET current_index := current_index + 1;
	END WHILE;
    RETURN is_comprised;
END;

