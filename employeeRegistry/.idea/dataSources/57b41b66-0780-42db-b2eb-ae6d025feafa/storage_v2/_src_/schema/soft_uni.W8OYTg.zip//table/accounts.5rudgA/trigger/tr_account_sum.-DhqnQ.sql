create definer = root@localhost trigger tr_account_sum
    after UPDATE
    on accounts
    for each row
BEGIN
	INSERT INTO logs (account_id, old_sum, new_sum)
    VALUES (OLD.id, OLD.balance, NEW.balance);
END;

